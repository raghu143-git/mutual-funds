package com.main;

import java.util.Scanner;

import com.dao.StudentDao;
import com.entity.Student;

public class MainApp 
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int choice;

		do
		{
			System.out.println("\n--- STUDENT CRUD MENU ---");
			System.out.println("1. Insert");
			System.out.println("2. Select");
			System.out.println("3. Update");
			System.out.println("4. Delete");
			System.out.println("5. Exit");
			System.out.print("Enter choice: ");

			choice = sc.nextInt();

			switch(choice)
			{
				case 1:
					Student s1 = new Student();
					System.out.print("Enter SID: ");
					s1.sid = sc.nextInt();
					System.out.print("Enter Name: ");
					s1.sname = sc.next();
					System.out.print("Enter Marks: ");
					s1.smarks = sc.nextDouble();

					StudentDao.insert(s1);
					break;

				case 2:
					StudentDao.selectAll();
					break;

				case 3:
					Student s2 = new Student();
					System.out.print("Enter SID to Update: ");
					s2.sid = sc.nextInt();
					System.out.print("Enter New Name: ");
					s2.sname = sc.next();
					System.out.print("Enter New Marks: ");
					s2.smarks = sc.nextDouble();

					StudentDao.update(s2);
					break;

				case 4:
					System.out.print("Enter SID to Delete: ");
					int sid = sc.nextInt();
					StudentDao.delete(sid);
					break;

				case 5:
					System.out.println("Thank You");
					break;

				default:
					System.out.println("Invalid Choice");
			}

		} while(choice != 5);

		sc.close();
	}
}
