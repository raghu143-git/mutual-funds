package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");

        String url = "jdbc:mysql://localhost:3306/klus8?useSSL=false&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "klu123456"; // your MySQL root password

        return DriverManager.getConnection(url, user, password);
    }
}
