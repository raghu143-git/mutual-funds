package com.entity;

public class Student 
{
	public int sid;
	public String sname;
	public double smarks;
}
