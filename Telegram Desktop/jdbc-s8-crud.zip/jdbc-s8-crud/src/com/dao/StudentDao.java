package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.connection.DBConnection;
import com.entity.Student;

public class StudentDao 
{
	// INSERT
	public static void insert(Student s) throws Exception
	{
		Connection con = DBConnection.getConection();
		PreparedStatement ps =
			con.prepareStatement(
				"insert into student(sid, sname, smarks) values(?,?,?)"
			);

		ps.setInt(1, s.sid);
		ps.setString(2, s.sname);
		ps.setDouble(3, s.smarks);

		ps.executeUpdate();
		System.out.println("Record inserted");

		ps.close();
		con.close();
	}

	// SELECT
	public static void selectAll() throws Exception
	{
		Connection con = DBConnection.getConection();
		PreparedStatement ps =
			con.prepareStatement("select * from student");

		ResultSet rs = ps.executeQuery();

		System.out.println("SID\tNAME\tMARKS");
		while(rs.next())
		{
			System.out.println(
				rs.getInt(1) + "\t" +
				rs.getString(2) + "\t" +
				rs.getDouble(3)
			);
		}

		rs.close();
		ps.close();
		con.close();
	}

	// UPDATE
	public static void update(Student s) throws Exception
	{
		Connection con = DBConnection.getConection();
		PreparedStatement ps =
			con.prepareStatement(
				"update student set sname=?, smarks=? where sid=?"
			);

		ps.setString(1, s.sname);
		ps.setDouble(2, s.smarks);
		ps.setInt(3, s.sid);

		ps.executeUpdate();
		System.out.println("Record updated");

		ps.close();
		con.close();
	}

	// DELETE
	public static void delete(int sid) throws Exception
	{
		Connection con = DBConnection.getConection();
		PreparedStatement ps =
			con.prepareStatement(
				"delete from student where sid=?"
			);

		ps.setInt(1, sid);

		ps.executeUpdate();
		System.out.println("Record deleted");

		ps.close();
		con.close();
	}
}
